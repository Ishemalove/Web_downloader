---
name: Question
about: Ask a question
---

As clearly indicated in [the Log4j support page](https://logging.apache.org/log4j/2.x/support.html#issues), **please use either GitHub Discussions or mailing lists for questions!**

Issues asking questions will be removed, and asked to post questions to GitHub Discussions or mailing lists instead.
